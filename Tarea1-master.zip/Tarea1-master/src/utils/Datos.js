export const tasks = [{
    id:1,
    text:"Este es el cuadrado 1",
    completed:"De color azul"
},{
    id:2,
    text:"Este es el cuadrado 2",
    completed:"De color rojo"
},{
    id:3,
    text:"Este es el cuadrado 3",
    completed:"De color amarillo"
}];